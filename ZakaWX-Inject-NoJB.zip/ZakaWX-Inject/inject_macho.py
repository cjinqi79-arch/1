#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
inject_macho.py — 给 Mach-O 主二进制加一条 LC_LOAD_DYLIB 加载命令

用途：重签名注入必备的一步。把 ZakaWX.dylib 写进微信主二进制的加载列表，
      iOS 启动微信时 dyld 就会一并把这个 dylib 载入。

设计原则（很重要）：
  只做"往里写一条 load command"这一件事，绝不移动已有任何内容。
  Mach-O 头部在 load command 区域之后本身有链接器留下的空白，
  空间够就直接写；空间不够本脚本会明确报错并让你换工具，
  而不是硬去做风险很高的镜像结构变形（那才是把包做废的常见原因）。

支持：thin arm64、fat（多架构）二进制。会自动备份原文件。
"""

import argparse
import os
import shutil
import struct
import sys

MH_MAGIC_64 = 0xFEEDFACF
FAT_MAGIC = 0xCAFEBABE
FAT_MAGIC_64 = 0xCAFEBABF

LC_REQ_DYLD = 0x80000000
LC_SEGMENT_64 = 0x19
LC_LOAD_DYLIB = 0x0C
LC_ID_DYLIB = 0x0D
LC_RPATH = 0x1C | LC_REQ_DYLD

MACH_HEADER_64_SIZE = 32
DEFAULT_INSTALL_NAME = "@executable_path/ZakaWX.dylib"
RPATH_INSTALL_NAME = "@rpath/ZakaWX.dylib"


def align_up(value, alignment):
    if alignment <= 1:
        return value
    return (value + alignment - 1) // alignment * alignment


class MachOError(Exception):
    pass


def iter_slices(data):
    """产出 (base_offset, size, cpu_name)。fat 二进制会产出多个。"""
    if len(data) < 4:
        raise MachOError("文件太小，不是 Mach-O")

    magic_be = struct.unpack_from(">I", data, 0)[0]
    magic_le = struct.unpack_from("<I", data, 0)[0]

    if magic_le in (MH_MAGIC_64,):
        yield 0, len(data), "thin"
        return

    if magic_be in (FAT_MAGIC, FAT_MAGIC_64):
        is64 = magic_be == FAT_MAGIC_64
        nfat = struct.unpack_from(">I", data, 4)[0]
        entry_size = 32 if is64 else 20
        for i in range(nfat):
            base = 8 + i * entry_size
            cputype, cpusubtype, offset, size, _align = struct.unpack_from(">5I", data, base)
            cpu_name = {0x0100000C: "arm64", 0x0000000C: "arm"}.get(cputype, "cpu-%x" % cputype)
            yield offset, size, cpu_name
        return

    raise MachOError("无法识别的 Mach-O magic: 0x%08x" % magic_le)


def parse_load_commands(data, base):
    if struct.unpack_from("<I", data, base)[0] != MH_MAGIC_64:
        raise MachOError("只支持 64 位 Mach-O（当前不是）")

    (magic, cputype, cpusubtype, filetype,
     ncmds, sizeofcmds, flags, _reserved) = struct.unpack_from("<8I", data, base)

    if ncmds == 0 or ncmds > 20000:
        raise MachOError("load command 数量异常 (%d)，文件可能已损坏" % ncmds)
    if sizeofcmds <= 0 or 32 + sizeofcmds > len(data):
        raise MachOError("sizeofcmds 异常 (%d)" % sizeofcmds)

    commands = []
    off = base + MACH_HEADER_64_SIZE
    for _ in range(ncmds):
        if off + 8 > len(data):
            raise MachOError("load command 越界")
        cmd, cmdsize = struct.unpack_from("<2I", data, off)
        if cmdsize < 8 or off + cmdsize > len(data):
            raise MachOError("load command 尺寸异常 (cmd=0x%x size=%d)" % (cmd, cmdsize))
        commands.append((off, cmd, cmdsize))
        off += cmdsize

    return {
        "magic": magic, "cputype": cputype, "cpusubtype": cpusubtype,
        "filetype": filetype, "ncmds": ncmds, "sizeofcmds": sizeofcmds,
        "flags": flags, "commands": commands,
    }


def existing_dylibs(data, info, path_lower):
    """看看是不是已经注入过了"""
    for (off, cmd, cmdsize) in info["commands"]:
        if cmd != LC_LOAD_DYLIB:
            continue
        name_off = struct.unpack_from("<I", data, off + 8)[0]
        name_start = off + name_off
        end = data.find(b"\x00", name_start, off + cmdsize)
        if end < 0:
            continue
        name = data[name_start:end].decode("utf-8", "replace")
        if os.path.basename(name).lower() == path_lower:
            return name
    return None


def min_content_offset(data, info, base):
    """header + load command 区域之后，第一段真实内容的文件偏移"""
    lowest = None
    for (off, cmd, cmdsize) in info["commands"]:
        if cmd != LC_SEGMENT_64:
            continue
        nsects = struct.unpack_from("<I", data, off + 64)[0]
        sec_off = off + 72
        for _ in range(nsects):
            if sec_off + 80 > len(data):
                break
            s_offset = struct.unpack_from("<I", data, sec_off + 48)[0]
            s_size = struct.unpack_from("<Q", data, sec_off + 40)[0]
            if s_offset > 0 and s_size > 0:
                if lowest is None or s_offset < lowest:
                    lowest = s_offset
            sec_off += 80
        seg_fileoff = struct.unpack_from("<Q", data, off + 40)[0]
        seg_filesize = struct.unpack_from("<Q", data, off + 48)[0]
        if seg_fileoff > 0 and seg_filesize > 0:
            if lowest is None or seg_fileoff < lowest:
                lowest = seg_fileoff
    return lowest


def slice_already_has_rpath(data, info, rpath_value):
    for (off, cmd, cmdsize) in info["commands"]:
        if cmd != LC_RPATH:
            continue
        name_off = struct.unpack_from("<I", data, off + 8)[0]
        name_start = off + name_off
        end = data.find(b"\x00", name_start, off + cmdsize)
        if end < 0:
            continue
        if data[name_start:end].decode("utf-8", "replace") == rpath_value:
            return True
    return False


def build_load_command(install_name):
    raw = install_name.encode("utf-8") + b"\x00"
    total = align_up(24 + len(raw), 8)
    body = struct.pack("<6I", LC_LOAD_DYLIB, total, 24, 0, 0x10000, 0x10000)
    body += raw
    body += b"\x00" * (total - len(body))
    return body, total


def inject_into_slice(buf, base, size, dylib_basename, prefer_rpath):
    data = buf
    info = parse_load_commands(data, base)

    already = existing_dylibs(data, info, dylib_basename)
    if already:
        return False, "已经注入过了 (%s)" % already, info

    candidates = []
    if prefer_rpath and slice_already_has_rpath(data, info, "@executable_path/Frameworks"):
        candidates.append(RPATH_INSTALL_NAME)
    candidates.append(DEFAULT_INSTALL_NAME)
    candidates.append(RPATH_INSTALL_NAME)

    content_start = min_content_offset(data, info, base)
    if content_start is None:
        raise MachOError("找不到可用的内容起始偏移，文件结构异常")

    lc_end = base + MACH_HEADER_64_SIZE + info["sizeofcmds"]
    avail = content_start - lc_end

    chosen = None
    chosen_size = 0
    for name in candidates:
        body, total = build_load_command(name)
        if total <= avail:
            chosen, chosen_size = body, total
            chosen_name = name
            break

    if chosen is None:
        need_min = align_up(24 + len(DEFAULT_INSTALL_NAME) + 1, 8)
        raise MachOError(
            "头部空白不够，放不下新的加载命令。\n"
            "    需要 %d 字节，可用 %d 字节。\n"
            "    这不是 bug，是这款 App 的链接器没留多余空间。\n"
            "    解决办法：改用 Sideloadly 注入（它自带扩展逻辑），或者用 insert_dylib / optool。"
            % (need_min, avail)
        )

    # 确认这块区域确实是空白（全零），不是别人在用的数据
    region = data[lc_end:lc_end + chosen_size]
    if region.strip(b"\x00") != b"":
        raise MachOError("头部空白区不是空的，为安全起见中止（请改用 Sideloadly / insert_dylib）")

    data[lc_end:lc_end + chosen_size] = chosen
    struct.pack_into("<2I", data, base + 16, info["ncmds"] + 1, info["sizeofcmds"] + chosen_size)

    # 自检：重新解析一遍
    check = parse_load_commands(data, base)
    if check["ncmds"] != info["ncmds"] + 1 or check["sizeofcmds"] != info["sizeofcmds"] + chosen_size:
        raise MachOError("自检没通过，已放弃写入")
    found = existing_dylibs(data, check, dylib_basename)
    if found != chosen_name:
        raise MachOError("自检没通过（加载项没落到预期位置），已放弃写入")

    return True, chosen_name, check


def main():
    ap = argparse.ArgumentParser(description="给 Mach-O 加 dylib 加载命令（安全模式）")
    ap.add_argument("binary", help="目标主二进制，例如 Payload/WeChat.app/WeChat")
    ap.add_argument("--dylib-name", default=DEFAULT_INSTALL_NAME,
                    help="写进去的加载路径，默认 @executable_path/ZakaWX.dylib")
    ap.add_argument("--no-backup", action="store_true", help="不生成 .bak 备份")
    args = ap.parse_args()

    path = args.binary
    if not os.path.isfile(path):
        print("[x] 找不到文件: %s" % path)
        return 2

    with open(path, "rb") as fh:
        data = bytearray(fh.read())

    dylib_basename = os.path.basename(args.dylib_name).lower()
    prefer_rpath = args.dylib_name.startswith("@rpath")

    touched = 0
    try:
        for base, size, cpu in list(iter_slices(bytes(data))):
            try:
                changed, detail, _info = inject_into_slice(data, base, size, dylib_basename, prefer_rpath)
            except MachOError as exc:
                print("[x] %s 切片注入失败：%s" % (cpu, exc))
                return 1
            if changed:
                touched += 1
                print("[+] %s 切片：已写入加载项 %s" % (cpu, detail))
            else:
                print("[=] %s 切片：%s" % (cpu, detail))
    except MachOError as exc:
        print("[x] 解析失败：%s" % exc)
        return 1

    if touched == 0:
        print("[=] 没有任何改动，文件保持原样")
        return 0

    if not args.no_backup:
        backup = path + ".bak"
        if not os.path.exists(backup):
            shutil.copy2(path, backup)
            print("[*] 已备份原文件 -> %s" % backup)

    with open(path, "wb") as fh:
        fh.write(data)

    print("[ok] 注入完成：%s" % path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
