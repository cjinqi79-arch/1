#!/bin/bash
#
# inject.sh — 一键完成：解包 IPA → 注入 ZakaWX.dylib → 用你的证书重签 → 重新打包
#
# 只在 macOS 上跑（重签需要 Xcode 的 codesign）。
#
# 用法：
#   chmod +x inject.sh
#
#   1) 先看看你机器上有哪些可用签名证书：
#      security find-identity -v -p codesigning
#
#   2) 然后（用企业证书/个人证书 + 描述文件）：
#      ./inject.sh WeChat.ipa "Apple Distribution: 你的公司名 (TEAMID)" \
#                  --profile xxx.mobileprovision \
#                  --dylib ZakaWX.dylib \
#                  --out WeChat-ZakaWX.ipa
#
#   如果只有 p12 没导出证书名，先在钥匙串里导入 p12，再跑第 1 步拿名字。
#

set -euo pipefail

IPA=""
IDENTITY=""
PROFILE=""
DYLIB="ZakaWX.dylib"
OUT=""
BUNDLE_ID=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --profile)  PROFILE="$2"; shift 2 ;;
        --dylib)    DYLIB="$2"; shift 2 ;;
        --out)      OUT="$2"; shift 2 ;;
        --bundleid) BUNDLE_ID="$2"; shift 2 ;;
        -h|--help)
            sed -n '2,25p' "$0"; exit 0 ;;
        *)
            if [[ -z "$IPA" ]]; then IPA="$1";
            elif [[ -z "$IDENTITY" ]]; then IDENTITY="$1";
            else echo "[x] 多余的参数: $1"; exit 1; fi
            shift ;;
    esac
done

if [[ -z "$IPA" || -z "$IDENTITY" ]]; then
    echo "用法: ./inject.sh <WeChat.ipa> \"<签名证书名>\" [--profile p.mobileprovision] [--dylib ZakaWX.dylib] [--out 输出.ipa]"
    exit 1
fi

[[ -f "$IPA" ]]    || { echo "[x] 找不到 IPA: $IPA"; exit 1; }
[[ -f "$DYLIB" ]]  || { echo "[x] 找不到 dylib: $DYLIB（先跑 build-dylib.sh，或从云端编译结果里拿）"; exit 1; }

# 证书是否存在
if ! security find-identity -v -p codesigning | grep -qF "$IDENTITY"; then
    echo "[x] 钥匙串里找不到这个签名证书: $IDENTITY"
    echo "    可用证书列表："
    security find-identity -v -p codesigning | sed 's/^/      /'
    exit 1
fi

WORK="$(mktemp -d ./zaka-build.XXXXXX)"
trap 'rm -rf "$WORK"' EXIT

echo "[1/6] 解包 IPA ..."
unzip -q "$IPA" -d "$WORK"

APP_DIR="$(find "$WORK/Payload" -maxdepth 1 -name "*.app" -type d | head -n1)"
[[ -n "$APP_DIR" ]] || { echo "[x] 包里没找到 .app"; exit 1; }

APP_NAME="$(basename "$APP_DIR" .app)"
APP_BIN="$APP_DIR/$APP_NAME"
[[ -f "$APP_BIN" ]] || { echo "[x] 没找到主二进制: $APP_BIN"; exit 1; }

echo "      目标 App: $APP_NAME"

echo "[2/6] 提取原始 entitlements ..."
ENT="$WORK/entitlements.plist"
if codesign -d --entitlements :- "$APP_BIN" > "$ENT" 2>/dev/null && [[ -s "$ENT" ]]; then
    echo "      已从原包提取（保留推送/钥匙串等权限，避免装完登录异常）"
else
    echo "      [!] 提取失败，改用手写模板（请按注释把 TEAMID 换成你的）"
    cat > "$ENT" <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>application-identifier</key>
    <string>TEAMID.com.tencent.xin</string>
    <key>com.apple.developer.team-identifier</key>
    <string>TEAMID</string>
    <key>get-task-allow</key>
    <true/>
    <key>keychain-access-groups</key>
    <array>
        <string>TEAMID.*</string>
    </array>
</dict>
</plist>
EOF
fi

echo "[3/6] 放入 dylib 并注入加载命令 ..."
cp -f "$DYLIB" "$APP_DIR/$(basename "$DYLIB")"

# 先清掉原签名，避免注入后 codesign 报"已被签名"
rm -rf "$APP_DIR/_CodeSignature"
find "$APP_DIR" -name "_CodeSignature" -type d -exec rm -rf {} + 2>/dev/null || true

python3 "$(dirname "$0")/inject_macho.py" "$APP_BIN" --dylib-name "@executable_path/$(basename "$DYLIB")"

echo "[4/6] 替换描述文件 ..."
if [[ -n "$PROFILE" ]]; then
    [[ -f "$PROFILE" ]] || { echo "[x] 找不到描述文件: $PROFILE"; exit 1; }
    cp -f "$PROFILE" "$APP_DIR/embedded.mobileprovision"
    echo "      已写入新描述文件"
else
    echo "      [!] 没给 --profile，沿用原包里的描述文件（只有证书和原 App ID 匹配时才能装上）"
fi

if [[ -n "$BUNDLE_ID" ]]; then
    /usr/libexec/PlistBuddy -c "Set :CFBundleIdentifier $BUNDLE_ID" "$APP_DIR/Info.plist"
    echo "      Bundle ID -> $BUNDLE_ID"
fi

echo "[5/6] 重签（从内到外）..."
sign_one() {
    codesign --force --sign "$IDENTITY" --timestamp=none "$1" >/dev/null 2>&1 \
        || { echo "      [x] 签名失败: $1"; return 1; }
    return 0
}

# 5.1 frameworks
while IFS= read -r -d '' fw; do
    sign_one "$fw" || exit 1
done < <(find "$APP_DIR" -type d -name "*.framework" -print0 2>/dev/null)

# 5.2 独立的 dylib
while IFS= read -r -d '' dl; do
    sign_one "$dl" || exit 1
done < <(find "$APP_DIR" -type f -name "*.dylib" -print0 2>/dev/null)

# 5.3 扩展（插件/小组件）
while IFS= read -r -d '' ex; do
    sign_one "$ex" || exit 1
done < <(find "$APP_DIR" -type d -name "*.appex" -print0 2>/dev/null)

# 5.4 App 本体（带 entitlements）
codesign --force --sign "$IDENTITY" --entitlements "$ENT" --timestamp=none "$APP_DIR" >/dev/null \
    || { echo "[x] App 本体签名失败"; exit 1; }

echo "      签名完成"

echo "[6/6] 重新打包 ..."
[[ -n "$OUT" ]] || OUT="${APP_NAME}-ZakaWX.ipa"
OUT_ABS="$(cd "$(dirname "$OUT")" && pwd)/$(basename "$OUT")"
rm -f "$OUT_ABS"
( cd "$WORK" && zip -qry "$OUT_ABS" Payload )
echo "      输出: $OUT"

echo
echo "===== 结果自检 ====="
echo -n "  加载项: "
otool -L "$APP_BIN" 2>/dev/null | grep -i "ZakaWX" | head -n1 | sed 's/^[[:space:]]*//' || echo "(没查到，请手动跑 otool -L 看看)"
echo -n "  签名:   "
codesign -dv "$APP_DIR" 2>&1 | grep -E "Authority|TeamIdentifier" | head -n2 | tr '\n' ' '
echo
echo "  包大小: $(du -h "$OUT" | cut -f1)"
echo
echo "[ok] 全部完成。装之前先删掉手机上的旧微信，再装这个包。"
