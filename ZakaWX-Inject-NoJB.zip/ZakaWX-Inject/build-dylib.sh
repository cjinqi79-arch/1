#!/bin/bash
#
# build-dylib.sh — 在 macOS 上用 Xcode 自带工具链直接编出 ZakaWX.dylib
#
# 不需要 Theos，不需要越狱工具链。只要装了 Xcode（或 Command Line Tools）。
#
# 用法：
#   chmod +x build-dylib.sh
#   ./build-dylib.sh
#
# 产物：当前目录下的 ZakaWX.dylib
#

set -e

cd "$(dirname "$0")"

if ! command -v xcrun >/dev/null 2>&1; then
    echo "[x] 没找到 xcrun。请先装 Xcode 或 Command Line Tools：xcode-select --install"
    exit 1
fi

SDK=$(xcrun --sdk iphoneos --show-sdk-path 2>/dev/null) || {
    echo "[x] 取不到 iOS SDK，确认 Xcode 装好了：xcode-select -p"
    exit 1
}

echo "[*] 使用 SDK: $SDK"
echo "[*] 开始编译 ZakaWX.dylib ..."

xcrun --sdk iphoneos clang \
    -arch arm64 \
    -dynamiclib \
    -isysroot "$SDK" \
    -miphoneos-version-min=12.0 \
    -fobjc-arc \
    -O2 \
    -fvisibility=hidden \
    -framework Foundation \
    -framework UIKit \
    -o ZakaWX.dylib \
    Sources/ZakaWXConfig.m \
    Sources/ZakaWXHook.m \
    Sources/ZakaWXMain.m

echo "[*] 编译完成，做一次临时签名（注入后会被证书签名覆盖）"
codesign -f -s - ZakaWX.dylib 2>/dev/null || echo "[!] 临时签名跳过，不影响后面重签"

echo
echo "[ok] 产物: $(pwd)/ZakaWX.dylib"
ls -lh ZakaWX.dylib | awk '{print "     大小:", $5}'
echo
echo "下一步：把 ZakaWX.dylib 和 WeChat.ipa 一起交给 inject.sh，"
echo "       或者直接在 Sideloadly 里选择这个 dylib 注入。"
